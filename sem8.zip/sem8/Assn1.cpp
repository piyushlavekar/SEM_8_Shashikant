#include <iostream>
#include <vector>
#include <queue>
#include <omp.h>
#include <chrono>  // For timing

using namespace std;
using namespace std::chrono;  // So we can use high_resolution_clock easily

void parallelBFS(const vector<vector<int>> &graph, int start) {
    int n = graph.size();
    vector<bool> visited(n, false);
    queue<int> q;

    visited[start] = true;
    q.push(start);

    while (!q.empty()) {
        int size = q.size();

        #pragma omp parallel for
        for (int i = 0; i < size; i++) {
            int u;

            #pragma omp critical
            {
                u = q.front(); q.pop();
                // cout << "Visited: " << u << " by thread " << omp_get_thread_num() << endl;
            }

            for (int v : graph[u]) {
                if (!visited[v]) {
                    #pragma omp critical
                    {
                        if (!visited[v]) {
                            visited[v] = true;
                            q.push(v);
                        }
                    }
                }
            }
        }
    }
}

void parallelDFS(const vector<vector<int>> &graph, int node, vector<bool> &visited) {
    #pragma omp critical
    {
        if (visited[node]) return;
        visited[node] = true;
        cout << "Visited: " << node << " by thread " << endl;
    }

    #pragma omp parallel for
    for (int i = 0; i < graph[node].size(); i++) {
        int neighbor = graph[node][i];
        if (!visited[neighbor]) {
            #pragma omp task
            parallelDFS(graph, neighbor, visited);
        }
    }

    #pragma omp taskwait
}

int main() {
    vector<vector<int>> graph = {
        {1, 2},       // 0
        {0, 3, 4},    // 1
        {0, 5},       // 2
        {1},          // 3
        {1},          // 4
        {2}           // 5
    };

    // Measure time for Parallel BFS
    cout << "Parallel BFS:\n";
    auto start_bfs = high_resolution_clock::now();
    parallelBFS(graph, 0);
    auto end_bfs = high_resolution_clock::now();
    auto duration_bfs = duration_cast<milliseconds>(end_bfs - start_bfs);
    cout << "Time taken by Parallel BFS: " << duration_bfs.count() << " ms\n";

    // Measure time for Parallel DFS
    vector<bool> visited(graph.size(), false);
    cout << "\nParallel DFS:\n";
    auto start_dfs = high_resolution_clock::now();
    #pragma omp parallel
    {
        #pragma omp single
        parallelDFS(graph, 0, visited);
    }
    auto end_dfs = high_resolution_clock::now();
    auto duration_dfs = duration_cast<milliseconds>(end_dfs - start_dfs);
    cout << "Time taken by Parallel DFS: " << duration_dfs.count() << " ms\n";

    return 0;
}
