#include <iostream>
#include <omp.h>
#include <chrono>

using namespace std;
using namespace std::chrono;

int main() {
    const long long N = 100000000;  // 100 million
    long long sum = 0;

    // Time without OpenMP
    auto start = high_resolution_clock::now();
    for (long long i = 1; i <= N; i++) {
        sum += i * i;
    }
    auto end = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(end - start);
    cout << "Without OpenMP: Sum = " << sum << ", Time = " << duration.count() << " ms" << endl;

    // Reset sum
    sum = 0;

    // Time with OpenMP
    start = high_resolution_clock::now();
    #pragma omp parallel for reduction(+:sum)
    for (long long i = 1; i <= N; i++) {
        sum += i * i;
    }
    end = high_resolution_clock::now();
    duration = duration_cast<milliseconds>(end - start);
    cout << "With OpenMP:    Sum = " << sum << ", Time = " << duration.count() << " ms" << endl;

    return 0;
}
